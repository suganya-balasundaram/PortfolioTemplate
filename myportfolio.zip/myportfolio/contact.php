<?php 
$your_email ='suganyakavintech@gmail.com';// <<=== update to your email address

session_start();
$errors = '';
$fname = '';
$email = '';
$message1 = '';
$mobile = '';
if(isset($_POST['btnsave']))
{
	
	
	
	
	$fname = $_POST['fname'];
	$email = $_POST['email'];
	$message1 = $_POST['message1'];
	$mobile = $_POST['mobile'];
	///------------Do Validations-------------
	if(empty($name)||empty($email))
	{
		$errors .= "\n Name and Email are required fields. ";	
	}
	if(IsInjected($email))
	{
		$errors .= "\n Bad email value!";
	}
	if(empty($_SESSION['6_letters_code'] ) ||
	  strcasecmp($_SESSION['6_letters_code'], $_POST['6_letters_code']) != 0)
	{
	//Note: the captcha code is compared case insensitively.
	//if you want case sensitive match, update the check above to
	// strcmp()
		$errors .= "\n The captcha code does not match!";
	}
	
	if(empty($errors))
	{
		
		$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
mysql_select_db("loginsystem", $con);

$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$email=$_POST['email'];
	$mobile=$_POST['mobile'];
	$message1=$_POST['message1'];
	

	
$sql="INSERT INTO contactus (fname, lname, mobile, email, message1)
VALUES ('$_POST[fname]','$_POST[lname]','$_POST[mobile]','$_POST[email]','$_POST[message1]')";
if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }
echo "<font style='color:green;font-weight:900;'>Your Information Was Successfully Posted. ";
mysql_close($con);
		
		//send the email
		$to = $your_email;
		$subject="New form submission";
		$from = $your_email;
		
		
		$body = "A user  $name submitted the contact form:\n".
		"Name: $name\n".
		"Email: $email \n".
		"Mobile: \n ".
		"$user_message\n".
		"IP: $ip\n";	
		
		$headers = "From: $from \r\n";
		$headers .= "Reply-To: $visitor_email \r\n";
		
		mail($to, $subject, $body,$headers);
		
		header('Location: contact.php');
	}
}

// Function to validate against any email injection attempts
function IsInjected($str)
{
  $injections = array('(\n+)',
              '(\r+)',
              '(\t+)',
              '(%0A+)',
              '(%0D+)',
              '(%08+)',
              '(%09+)'
              );
  $inject = join('|', $injections);
  $inject = "/$inject/i";
  if(preg_match($inject,$str))
    {
    return true;
  }
  else
    {
    return false;
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="format-detection" content="telephone=no"/>
 <link rel="icon" href="images/favicon1.ico" type="image/x-icon">
    <title>Contacts</title>
 <link href="font-awesome-4.6.2/font-awesome-4.6.2/css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Links -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/cform.css">
    <link rel="stylesheet" href="css/google-map.css">
<link href="css/style1new.css" rel="stylesheet">
<script src='https://www.google.com/recaptcha/api.js'></script>
    <!--JS-->
 
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
 <script src="js/jquery.js"></script>
<script type="text/javascript">

   //Created / Generates the captcha function    
    function DrawCaptcha()
    {
        var a = Math.ceil(Math.random() * 10)+ '';
        var b = Math.ceil(Math.random() * 10)+ '';       
        var c = Math.ceil(Math.random() * 10)+ '';  
        var d = Math.ceil(Math.random() * 10)+ '';  
        var e = Math.ceil(Math.random() * 10)+ '';  
        var f = Math.ceil(Math.random() * 10)+ '';  
        var g = Math.ceil(Math.random() * 10)+ '';  
        var code = a + ' ' + b + ' ' + ' ' + c + ' ' + d + ' ' + e + ' '+ f + ' ' + g;
        document.getElementById("txtCaptcha").value = code
    }

    // Validate the Entered input aganist the generated security code function   
    function ValidCaptcha(){
        var str1 = removeSpaces(document.getElementById('txtCaptcha').value);
        var str2 = removeSpaces(document.getElementById('txtInput').value);
        if (str1 == str2) return true;        
        return false;
        
    }

    // Remove the spaces from the entered and generated code
    function removeSpaces(string)
    {
        return string.split(' ').join('');
    }
    
 
    </script>
    <!--[if lt IE 9]>
    <div style=' clear: both; text-align:center; position: relative;'>
        <a href="http://windows.microsoft.com/en-US/internet-explorer/..">
            <img src="images/ie8-panel/warning_bar_0000_us.jpg" border="0" height="42" width="820"
                 alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."/>
        </a>
    </div>
    <script src="js/html5shiv.js"></script>
    <![endif]-->
    <script src='js/device.min.js'></script>
	<script>
function phonenumber(inputtxt)  
{  
  var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;  
  if(inputtxt.value.match(phoneno))  
     {  
       return true;  
     }  
   else  
     {  
       
       return false;  
     }  
} 
</script>
<script language="Javascript" type="text/javascript">
 
        function onlyAlphabets(e, t) {
            try {
                if (window.event) {
                    var charCode = window.event.keyCode;
                }
                else if (e) {
                    var charCode = e.which;
                }
                else { return true; }
                if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
                    return true;
                else
                    return false;
            }
            catch (err) {
                alert(err.Description);
            }
        }
 
    </script>
<script>
   function validatenumerics(key)
 {
           //getting key code of pressed key
           var keycode = (key.which) ? key.which : key.keyCode;
           //comparing pressed keycodes

           if (keycode > 31 && (keycode < 48 || keycode > 57)) 
		   {
               
               return false;
           }
           else 
		   {
		   return true;
           }

	}</script>

<script>
function ValidateEmail(inputText)
{
    var x = inputText;
    var atpos = x.indexOf("@");
    var dotpos = x.lastIndexOf(".");
    if (atpos< 1 || dotpos<atpos+2 || dotpos+2>=x.length) {
        
document.getElementById("email").focus();
        return false;
    }
}

function validate(email) {

         
        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        if (reg.test(email.value) == false) 
        {
            alert('Invalid Email Address please include @');
            return false;
		document.getElementById("email").focus();	
        }

      
 }

</script>
<style>

.err
{
	font-family : Verdana, Helvetica, sans-serif;
	font-size : 12px;
	color: red;
}
</style>	
<script language="JavaScript" src="gen_validatorv31.js" type="text/javascript"></script>
</head>
<body onLoad="DrawCaptcha();" >
<div class="page">
    <!--========================================================
                              HEADER
    =========================================================-->
	 
   <?php $page = 'contact'; include("header.php"); ?>
      <!--========================================================
                              CONTENT
    =========================================================-->

    <main>

        <section class="well6 text-center">

            <div class="container">
                <h3>
                    contact info
                </h3>
               
                
                  
			
        	 <div class="map">
			<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
        	<div style="overflow:hidden;height:350px;width:100%;">
        		<div id="gmap_canvas" style="height:350px;width:100%"></div>
				<style>
					#gmap_canvas img
					{
						max-width:none!important;
						background:none!important
					}
                </style>
        		<a class="google-map-code" href="http://www.pureblack.de" id="get-map-data">werbeagentur</a>
        	</div>
			
			
			
			<script type="text/javascript" src="http://maps.google.com/maps/api/js?key=AIzaSyAelmepRkyOmPPCcYwlTK1ImKJXWYjXKB0"></script><script type="text/javascript"> 
			function init_map(){var myOptions = {zoom:14,center:new google.maps.LatLng(39.5747452,-75.86904570000002),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(39.5747452,-75.86904570000002)});infowindow = new google.maps.InfoWindow({content:"<b>C-DEVELOPMENTS</b><br/>166 RAINTREE LANE, ELKTON, MARYLAND 21922,<br/> USA." });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);
        	</script>  
			
			       
        </div>
        	
			
        		
			
                   
                     

               

                <div class="row offs4">
                    <div class="contact">
                        <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.6s">
                            <span class="fa fa-envelope"></span>
							<address class="marker">
                            <strong> info@c-developments.com
</strong></address>
                        </div>

                        <div class="col-md-4 col-sm-4 col-xs-12 mg-add wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.4s">
                            <span class="fa fa-mobile"></span>
							<address class="marker">
                            <strong>Ph:410.398.0234 </strong><br>
							  </address>
                        </div>

                        <div class="col-md-4 col-sm-4 col-xs-12 mg-add2 wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.2s">
                            <span class="fa fa-map-marker"></span>
                            <address class="marker">
							
							166 RAINTREE LANE,
ELKTON,   MARYLAND 21922,
USA.


                              
                            </address>
                        </div>
                    </div>

                </div>

            </div>
        </section>

        <section class="well9 bg-light cform">
            <div class="container text-center">
                <h3>contact form</h3>
               


               <form class='mailform err' method="post"  name="contact_form" onSubmit="MM_validateForm('from','','RisEmail','subject','','R','verif_box','','R','message','','R');return document.MM_returnValue" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" id='contact_form_errorloc'>
                    <input type="hidden" name="form-type" value="contact"/>
                    <fieldset class="row">
                        <div class="col-sm-6">
                  <label>
                    <p style="color:#000000;padding-bottom:12px"><i class="fa fa-star" aria-hidden="true" style="color:red;font-size:10px"></i>&nbsp; First Name:</p><input type="text" name="fname"  style="border:1px solid black"  onKeyPress="return onlyAlphabets(event,this);" id="bang" onKeyUp="f()" required >
                  </label>
                </div>
				<div class="col-sm-6">
                  <label>
                    <p style="color:#000000;padding-bottom:12px"><i class="fa fa-star" aria-hidden="true" style="color:red;font-size:10px"></i>&nbsp; Last Name:</p><input type="text" name="lname"  style="border:1px solid black" onKeyPress="return onlyAlphabets(event,this);" id="bang" onKeyUp="f()" required >
                  </label>
                </div>
				
				<div class="col-sm-6">
                  <label>
                    <p style="color:#000000;padding-bottom:12px"><i class="fa fa-star" aria-hidden="true" style="color:red;font-size:10px"></i>&nbsp; Contact Number:</p><input type="text" name="mobile" id="mobile1" style="border:1px solid black"  pattern="^\d{10}$" onKeyPress="return validatenumerics(event)" onBlur="return ValidateMobNumber('mobile1')" required>
                  </label>
                </div>
				
				<div class="col-sm-6">
                  <label>
                    <p style="color:#000000;padding-bottom:12px"><i class="fa fa-star" aria-hidden="true" style="color:red;font-size:10px"></i>&nbsp; Email Address:</p><input type="text" name="email" id="email" style="border:1px solid black"  onBlur="return validate(this)";       required  >
                  </label>
              </div>
			
				<div class="col-sm-6">
                  <label>
                    <p style="color:#000000;padding-bottom:12px">Message:</p><input type="text" name="message1" style="border:1px solid black;height:65px"        required  >
                  </label>
                </div>
				<br><br>
				<div class="col-sm-6">
				
							<label>
		


 <p style="color:#000000;padding-bottom:12px"><i class="fa fa-star" aria-hidden="true" style="color:red;font-size:10px"></i>&nbsp;Enter the code above here:</p><input id="6_letters_code" name="6_letters_code" type="text" style="border: 1px solid black;
    height: 65px;"><br><br/>
<img src="captcha_code_file.php?rand=1770986295" id='captchaimg' ><br>
<p style="color:black;">Can't read the image? click <a href='javascript: refreshCaptcha();' style="text-decoration:underline;color:blue;">here</a> to refresh</p><br>
<?php
if(!empty($errors)){
echo "<p class='err'>".nl2br($errors)."</p>";
}
?>
 <!-- if the variable "wrong_code" is sent from previous page then display the error field -->
           </label></div>
		   <div class="col-sm-6" >
		  <label>
		  
		 
		 			
 <input name="btnsave" type="submit" class="btn btn-primary text-uppercase" size="25" value="SUBMIT" style="color:#ffffff;width:100px;height:50px;background-color:#002c5b;"> 
							 </label>
							

		  
							        </div>    </div>

                        
                    </fieldset>
                </form>
            </div>
        </section>


    </main>
<!-- 
/* 	This counter has been created by Nicola Delbono <key5@key5.com>			*/
/*	you can modify and/or use the code for free. Pleeease keep these three lines		*/
/*	into your customized counter									*/
  -->


    <!--========================================================
                            FOOTER
    =========================================================-->
     
  <?php include("footer.php"); ?>
	
    </div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
<script src="js/tm.js"></script>
<!-- </script> -->

<script language="JavaScript">
// Code for validating the form
// Visit http://www.javascript-coder.com/html-form/javascript-form-validation.phtml
// for details
var frmvalidator  = new Validator("contact_form");
//remove the following two lines if you like error message box popups
frmvalidator.EnableOnPageErrorDisplaySingleBox();
frmvalidator.EnableMsgsTogether();

frmvalidator.addValidation("name","req","Please provide your name"); 
frmvalidator.addValidation("email","req","Please provide your email"); 
frmvalidator.addValidation("email","email","Please enter a valid email address"); 
</script>
<script language='JavaScript' type='text/javascript'>
function refreshCaptcha()
{
	var img = document.images['captchaimg'];
	img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
}
</script>
</body>
</html>
<?php 
$your_email ='bsuganya07@gmail.com';// <<=== update to your email address

session_start();
$errors = '';
$fname = '';
$email = '';
$subject1 = '';
$message1 = '';

if(isset($_POST['btnsave']))
{
	
	
	
	
	$fname = $_POST['fname'];
	$email = $_POST['email'];
	$message1 = $_POST['message1'];
	$subject1 = $_POST['subject1'];
	///------------Do Validations-------------
	if(empty($fname)||empty($email))
	{
		$errors .= "\n Name and Email are required fields. ";	
	}
	if(IsInjected($email))
	{
		$errors .= "\n Bad email value!";
	}
	
	
	if(empty($errors))
	{
		
	
		
		//send the email
		$to = $your_email;
		$subject="My website response";
		$from = $your_email;
		
		
		$body = "A user  $fname submitted the contact form:\n".
		"Name: $fname\n".
		"Email: $email \n".
		"subject: $subject1\n ".
		"$message1\n".
		
		
		$headers = "From: $from \r\n";
		
		
		mail($to, $subject, $body,$headers);
		
		$errors .= "\n Thank you for contacting me. I will contact you soon. ";
	}
}

// Function to validate against any email injection attempts
function IsInjected($str)
{
  $injections = array('(\n+)',
              '(\r+)',
              '(\t+)',
              '(%0A+)',
              '(%0D+)',
              '(%08+)',
              '(%09+)'
              );
  $inject = join('|', $injections);
  $inject = "/$inject/i";
  if(preg_match($inject,$str))
    {
    return true;
  }
  else
    {
    return false;
  }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <meta name="description" content="" />
    <meta name="author" content="" />
	<link href="image/favicon.ico" rel="icon" type="image/x-icon" />
    <link
      href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700,900"
      rel="stylesheet"
    />

    <title>Suganya Portfolio</title>

    <link href="css/bootstrap.min.css" rel="stylesheet" />

  
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/templatemo-style.css" />
    <link rel="stylesheet" href="css/owl.css" />
    <link rel="stylesheet" href="css/lightbox.css" />
	
	<style>

.err
{
	font-family : Verdana, Helvetica, sans-serif;
	font-size : 20px;
	color: #28a745;
}
</style>
  </head>

  <body>
    <div id="page-wraper">
      
      <div class="responsive-nav">
        <i class="fa fa-bars" id="menu-toggle"></i>
        <div id="menu" class="menu">
          <i class="fa fa-times" id="menu-close"></i>
          <div class="container">
            <div class="image">
              <a href="#"><img src="image/my1.jpg" alt="" /></a>
            </div>
            <div class="author-content">
              <h4>Suganya Balasundaram</h4>
              <span>Web Designer</span>
            </div>
            <nav class="main-nav" role="navigation">
              <ul class="main-menu">
                <li><a href="#section1">About Me</a></li>
                <li><a href="#section2">What I’m good at</a></li>
                <li><a href="#section3">My Work</a></li>
                <li><a href="#section4">Contact Me</a></li>
              </ul>
            </nav>
            <div class="social-network">
             <i class="fa fa-envelope" aria-hidden="true" style="color:white;"></i> <span style="color:white;">bsuganya07@gmail.com</span>
            </div>
            <div class="copyright-text">
              <p>Copyright 2020 Suganya Design</p>
            </div>
          </div>
        </div>
      </div>

      <section class="section about-me" data-section="section1">
        <div class="container">
          <div class="section-heading">
		  
		   <?php
if(!empty($errors)){
echo "<p class='err'>".nl2br($errors)."</p>";
}
?>
            <h2>About Me</h2>
            <div class="line-dec"></div>
            <span
              >I design and code beautifully simple things, and I love what I do.</span
            >
          </div>
          <div class="left-image-post">
            <div class="row">
              <div class="col-md-6">
                <div class="left-image">
                  <img src="image/left-image.jpg" alt="" />
                </div>
              </div>
              <div class="col-md-6">
                <div class="right-text">
                  <h4>Who I Am?</h4>
                  <p>
                    My name's Suganya Balasundaram. I'm a web designer and developer from Trichy, India.

I have 5 years experienced in this field. I create custom websites to help businesses do better online. There’s nothing I enjoy more than designing and developing good websites for nice people. It really is that simple.

I’ve spent many years trying to perfect what I do and while I’ll never be perfect, I do my best to come close.

If you’ve got a project you’d like to work on with me just get in touch and we can get to work!
                  </p>
                 
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </section>

      <section class="section my-services" data-section="section2">
        <div class="container">
          <div class="section-heading">
            <h2>What I’m good at?</h2>
            <div class="line-dec"></div>
         
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="service-item">
                <div class="first-service-icon service-icon"></div>
                <h4>Web Design</h4>
				
				<h6>User Focused</h6>
                <p>
                 A website should be designed for the people who will use it, so that's exactly what I do. User focused design should be the primary goal of any website.
                </p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="service-item">
                <div class="second-service-icon service-icon"></div>
                <h4>Web Development</h4>
				<h6>Responsive and Fast</h6>
                <p>
                  Every website should be built with two primary goals: Firstly, it needs to work across all devices. Secondly, it needs to be fast as possible.
                </p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="service-item">
                <div class="third-service-icon service-icon"></div>
                <h4>HTML / CSS</h4>
                <p>
                  Creating a strong foundation for a website means getting the HTML and CSS architecture right. If you've got a design I can create the front-end code for it.
                </p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="service-item">
                <div class="fourth-service-icon service-icon"></div>
                <h4>Performance</h4>
                <p>
                  Having a fast website is key to keeping people around which ultimately converts them into customers. 
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="section my-work" data-section="section3">
        <div class="container">
          <div class="section-heading">
            <h2>My Work</h2>
            <div class="line-dec"></div>
            <span
              >Here are a few design projects I've worked.</span
            >
          </div>
          <div class="row">
            <div class="isotope-wrapper">
              <form class="isotope-toolbar">
                <label
                  ><input
                    type="radio"
                    data-type="*"
                    checked=""
                    name="isotope-filter"
                  />
                  <span>all</span></label
                >
                <label
                  ><input
                    type="radio"
                    data-type="travels"
                    name="isotope-filter"
                  />
                  <span>travels</span></label
                >
                <label
                  ><input
                    type="radio"
                    data-type="engineering"
                    name="isotope-filter"
                  />
                  <span>engineering</span></label
                >
                <label
                  ><input
                    type="radio"
                    data-type="realestate"
                    name="isotope-filter"
                  />
                  <span>realestate</span></label
                >
				
				                <label
                  ><input
                    type="radio"
                    data-type="restaurant"
                    name="isotope-filter"
                  />
                  <span>restaurant</span></label
                >
              </form>
              <div class="isotope-box">
                <div class="isotope-item" data-type="engineering">
                  <figure class="snip1321">
                    <img
                      src="image/mantech.jpg"
                      alt="sq-sample26"
                    />
                    <figcaption>
                     <h4>MANTECH GROUP</h4>
                      <a 
                        href="http://www.mantech8.com/" target="_blank"
                        
                        class="button">View Site
                      </a>
                      
                    </figcaption>
                  </figure>
                </div>

                <div class="isotope-item" data-type="realestate">
                  <figure class="snip1321">
                    <img
                      src="image/cdevelopments.jpg"
                      alt="sq-sample26"
                    />
                    <figcaption>
					<h4>C-DEVELOPMENTS</h4>
                      <a 
                        href="http://c-developments.com/home.php" target="_blank"
                        
                        class="button">View Site
                      </a>
                      
                     
                    </figcaption>
                  </figure>
                </div>

                <div class="isotope-item" data-type="animals">
                  <figure class="snip1321">
                    <img
                      src="image/sriambikas.jpg"
                      alt="sq-sample26"
                    />
                    <figcaption>
                      <h4>SRI AMBIKAS PTE LTD</h4>
                      <a 
                        href="http://sriambikas.com/" target="_blank"
                        
                        class="button">View Site
                      </a>
                    </figcaption>
                  </figure>
                </div>

                <div class="isotope-item" data-type="restaurant">
                  <figure class="snip1321">
                    <img
                      src="image/anjappar.jpg"
                      alt="sq-sample26"
                    />
                    <figcaption>
                       <h4>ANJAPPAR</h4>
                      <a 
                        href="http://anjappar.com.sg/" target="_blank"
                        
                        class="button">View Site
                      </a>
                    </figcaption>
                  </figure>
                </div>

                <div class="isotope-item" data-type="travels">
                  <figure class="snip1321">
                    <img
                      src="image/trichy.jpg"
                      alt="sq-sample26"
                    />
                    <figcaption>
                     <h4>TRICHY RASI TRAVELS</h4>
                      <a 
                        href="http://www.trichyrasitravels.com/" target="_blank"
                        
                        class="button">View Site
                      </a>
                    </figcaption>
                  </figure>
                </div>

                <div class="isotope-item" data-type="">
                  <figure class="snip1321">
                    <img
                      src="image/inuson.jpg"
                      alt="sq-sample26"
                    />
                    <figcaption>
                      <h4>INUSON INTERNATIONAL INC</h4>
                      <a 
                        href="https://www.inuson.com/" target="_blank"
                        
                        class="button">View Site
                      </a>
                    </figcaption>
                  </figure>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="section contact-me" data-section="section4">
        <div class="container">
          <div class="section-heading">
            <h2>Contact Me</h2>
            <div class="line-dec"></div>
            <span
              >
			  If you’d like to chat about a project please fill in the form below and I’ll get back within 1-2 days.
			  </span
            >
          </div>
          <div class="row">
            <div class="right-content">
              <div class="container">
                <form id="contact" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="post">
                  <div class="row">
                    <div class="col-md-6">
                      <fieldset>
                        <input
                          name="fname"
                          type="text"
                          class="form-control"
                          id="name"
                          placeholder="Your name..."
                          required=""
                        />
                      </fieldset>
                    </div>
                    <div class="col-md-6">
                      <fieldset>
                        <input
                          name="email"
                          type="email"
                          class="form-control"
                          id="email"
                          placeholder="Your email..."
                          required=""
                        />
                      </fieldset>
                    </div>
                    <div class="col-md-12">
                      <fieldset>
                        <input
                          name="subject1"
                          type="text"
                          class="form-control"
                          id="subject"
                          placeholder="Subject..."
                          required=""
                        />
                      </fieldset>
                    </div>
                    <div class="col-md-12">
                      <fieldset>
                        <textarea
                          name="message1"
                          rows="6"
                          class="form-control"
                          id="message"
                          placeholder="Your message..."
                          required=""
                        ></textarea>
                      </fieldset>
                    </div>
                    <div class="col-md-12">
                      <fieldset>
					  
					 
					  
                        <button type="submit" name="btnsave" id="form-submit" class="button">
                          Send Message
                        </button>
                      </fieldset>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>

   
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>

    <script src="js/isotope.min.js"></script>
    <script src="js/owl-carousel.js"></script>
    <script src="js/lightbox.js"></script>
    <script src="js/custom.js"></script>
    <script>
      
      $(".main-menu li:first").addClass("active");

      var showSection = function showSection(section, isAnimate) {
        var direction = section.replace(/#/, ""),
          reqSection = $(".section").filter(
            '[data-section="' + direction + '"]'
          ),
          reqSectionPos = reqSection.offset().top - 0;

        if (isAnimate) {
          $("body, html").animate(
            {
              scrollTop: reqSectionPos
            },
            800
          );
        } else {
          $("body, html").scrollTop(reqSectionPos);
        }
      };

      var checkSection = function checkSection() {
        $(".section").each(function() {
          var $this = $(this),
            topEdge = $this.offset().top - 80,
            bottomEdge = topEdge + $this.height(),
            wScroll = $(window).scrollTop();
          if (topEdge < wScroll && bottomEdge > wScroll) {
            var currentId = $this.data("section"),
              reqLink = $("a").filter("[href*=\\#" + currentId + "]");
            reqLink
              .closest("li")
              .addClass("active")
              .siblings()
              .removeClass("active");
          }
        });
      };

      $(".main-menu").on("click", "a", function(e) {
        e.preventDefault();
        showSection($(this).attr("href"), true);
      });

      $(window).scroll(function() {
        checkSection();
      });
    </script>
  </body>
</html>
